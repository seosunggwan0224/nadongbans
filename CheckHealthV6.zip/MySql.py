import pymysql 
from datetime import date

conn = pymysql.connect(host='localhost', user='LeeGiSeung', password='Hh134679852!',db="Health", charset='utf8') 
cursor = conn.cursor() 

# sql = "CREATE TABLE user (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,Alcohol INT,Outside INT,Exercise INT, Today DATE);"
# delsql = "DROP TABLE user"
# searchsql = "SELECT * FROM user;"
# cursor.execute(delsql) 
# cursor.execute(sql) 

# 'user' 테이블 생성
# create_table_sql = "CREATE TABLE user (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, Alcohol INT, Outside INT, Exercise INT, Today DATE);"
# cursor.execute(create_table_sql)
# conn.commit()

# 테이블 생성 부분 주석 처리
# create_table_sql = "CREATE TABLE user (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, Alcohol INT, Outside INT, Exercise INT, Today DATE);"
# cursor.execute(create_table_sql)
# conn.commit()

# 새로운 레코드 추가
insert_sql = "INSERT INTO user (Alcohol, Outside, Exercise, Today) VALUES (1, 0, 0, %s);"
cursor.execute(insert_sql, "2024-4-25")
conn.commit()


# 테이블 내용 확인
select_sql = "SELECT * FROM user;"
cursor.execute(select_sql)

# 결과 가져오기
rows = cursor.fetchall()

# 가져온 결과 출력
for row in rows:
    print(row)

conn.close()