let date = new Date();
let global_data;

// 모달 가져오기
var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];

// 사용자가 <span> (x)를 클릭하면 모달 닫기
span.onclick = function() {
    modal.style.display = 'none';
}

// 사용자가 모달 바깥의 어떤 곳을 클릭하면 모달 닫기
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

function formatDateComponent(component) {
    return component < 10 ? `0${component}` : component;
}

document.addEventListener('DOMContentLoaded', function() {
    renderCalendar();
});

function startApp() {
    renderCalendar(); // 달력 초기 상태를 렌더링합니다.
    fetchDataAndUpdate(); // 데이터 가져오기 및 업데이트
}

function fetchDataAndUpdate() {
    fetch('/process_voice_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: '음성 입력 시작' })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            global_data = data;
            updateCalendarWithData(data); // 서버 응답이 있을 경우 달력을 업데이트합니다.
        })
        .catch(error => console.error('Error:', error));
}

function renderCalendar() {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const prevLast = new Date(viewYear, viewMonth, 0);
    const thisLast = new Date(viewYear, viewMonth + 1, 0);

    const PLDate = prevLast.getDate();
    const PLDay = prevLast.getDay();

    const TLDate = thisLast.getDate();
    const TLDay = thisLast.getDay();

    const prevDates = [];
    const thisDates = [...Array(TLDate + 1).keys()].slice(1);
    const nextDates = [];

    if (PLDay !== 6) {
        for (let i = 0; i < PLDay + 1; i++) {
            prevDates.unshift(PLDate - i);
        }
    }

    for (let i = 1; i < 7 - TLDay; i++) {
        nextDates.push(i);
    }

    const dates = prevDates.concat(thisDates, nextDates);
    const firstDateIndex = dates.indexOf(1);
    const lastDateIndex = dates.lastIndexOf(TLDate);

    document.querySelector('.year-month').textContent = `${viewYear}년 ${viewMonth + 1}월`;

    const datesElement = document.querySelector('.dates');
    datesElement.innerHTML = ''; // 이전 날짜 클리어

    dates.forEach((date, i) => {
        const dateElement = document.createElement('div');
        dateElement.classList.add('date');
        const formattedDate = formatDateComponent(date);
        dateElement.setAttribute('data-date', `${viewYear}-${viewMonth + 1}-${formattedDate}`);
        
        const spanElement = document.createElement('span');
        spanElement.classList.add(i >= firstDateIndex && i < lastDateIndex + 1 ? 'this' : 'other');
        spanElement.textContent = date;
        dateElement.appendChild(spanElement);

        // 날짜 클릭 이벤트 리스너 추가
        dateElement.addEventListener('click', function() {
            modal.style.display = 'block'; // 모달을 보이게 설정
            const selectedDate = dateElement.getAttribute('data-date'); // 클릭된 날짜를 가져옵니다.
            fetchHealthInfo(selectedDate); // 수정된 함수 호출
        });

        // 최종적으로 dateElement를 datesElement에 추가
        datesElement.appendChild(dateElement);
    });
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();
    // 오늘 날짜 하이라이트
    if (viewMonth === todayMonth) {
        const datesElements = document.querySelectorAll('.this');
        for (let dateElement of datesElements) {
            const dateNum = parseInt(dateElement.innerText, 10);

            if (dateNum === todayDate) {
                dateElement.classList.add('today');
                break;
            }
        }
    }
}

function fetchHealthInfo(selectedDate) {
    // 주의: URL 경로를 Flask 라우트 경로에 맞게 수정하세요.
    fetch('/process_selected_date?date=' + selectedDate)
    .then(response => response.json())
    .then(data => {
        if (data) {
            // 모달 창에 데이터 표시
            document.getElementById('date-info').innerText = "날짜: " + selectedDate;
            document.getElementById('exercise-info').innerText = "운동 여부: " + (data.exercise ? "예" : "아니오");
            document.getElementById('outside-info').innerText = "외출 여부: " + (data.outside ? "예" : "아니오");
            document.getElementById('alcohol-info').innerText = "음주 여부: " + (data.alcohol ? "예" : "아니오");

            // 모달 창 열기
            openModal();
        } else {
            alert('데이터를 찾을 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('데이터를 가져오는 중 오류가 발생했습니다.');
    });
}

function updateCalendarWithData(data) {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const formattedData = data.map(item => ({
        ...item,
        date: `${viewYear}-${viewMonth + 1}-${formatDateComponent(item.date)}`
    }));

    const dates = document.querySelectorAll('.date');
    dates.forEach(dateElement => {
        const dataDate = dateElement.getAttribute('data-date');
        const dayData = formattedData.find(d => d.date === dataDate);
        if (dayData) {
            // 데이터에 따른 클래스 추가 등
        }
    });
}

function openModal() {
    console.log("모달 창 열렸습니다.");
    document.getElementById('myModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

span.onclick = function() {
    modal.style.display = 'none';
};

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};
