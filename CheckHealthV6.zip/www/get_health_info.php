<?php
mysqli_report(MYSQLI_REPORT_ALL); // MySQLi 오류 활성화

$host = 'localhost';
$db_user = 'LeeGiSeung';
$db_pass = 'Hh134679852!';
$db_name = 'Health';

try {
    $conn = new mysqli($host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $date = $_GET['date'];
    
    // 날짜 형식 변환
    $formatted_date = date('Y-m-d', strtotime($date));

    $query = $conn->prepare("SELECT Alcohol, Outside, Exercise FROM user WHERE Today = ?");
    $query->bind_param("s", $formatted_date);
    $query->execute();
    $result = $query->get_result();

    header('Content-Type: application/json');
    if ($data = $result->fetch_assoc()) {
        echo json_encode($data);
    } else {
        echo json_encode(array('error' => 'No data found for this date.'));
    }

    $conn->close();
} catch (Exception $e) {
    // 오류 처리
    echo json_encode(array('error' => $e->getMessage()));
}
?>
