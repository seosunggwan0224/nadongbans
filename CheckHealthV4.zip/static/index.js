let date = new Date();

// 모달 가져오기
var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];

// 사용자가 <span> (x)를 클릭하면 모달 닫기
span.onclick = function() {
    modal.style.display = 'none';
}

// 사용자가 모달 바깥의 어떤 곳을 클릭하면 모달 닫기
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

function formatDateComponent(component) {
    return component < 10 ? `0${component}` : component;
}

document.addEventListener('DOMContentLoaded', function() {
    startApp(); // 웹 페이지 로드 시 자동으로 달력을 렌더링하고 데이터를 가져옵니다.
});

function startApp() {
    renderCalendar(); // 달력 초기 상태를 렌더링합니다.
    fetchDataAndUpdate(); // 데이터 가져오기 및 업데이트
}

function fetchDataAndUpdate() {
    console.log('Server response:', data);
    fetch('/process_voice_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: '음성 입력 시작' })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            updateCalendarWithData(data); // 서버 응답이 있을 경우 달력을 업데이트합니다.
        })
        .catch(error => console.error('Error:', error));
}

function renderCalendar() {
    console.log("달력 제대로 열림");
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const prevLast = new Date(viewYear, viewMonth, 0);
    const thisLast = new Date(viewYear, viewMonth + 1, 0);

    const PLDate = prevLast.getDate();
    const PLDay = prevLast.getDay();

    const TLDate = thisLast.getDate();
    const TLDay = thisLast.getDay();

    const prevDates = [];
    const thisDates = [...Array(TLDate + 1).keys()].slice(1);
    const nextDates = [];

    if (PLDay !== 6) {
        for (let i = 0; i < PLDay + 1; i++) {
            prevDates.unshift(PLDate - i);
        }
    }

    for (let i = 1; i < 7 - TLDay; i++) {
        nextDates.push(i);
    }

    const dates = prevDates.concat(thisDates, nextDates);
    const firstDateIndex = dates.indexOf(1);
    const lastDateIndex = dates.lastIndexOf(TLDate);

    document.querySelector('.year-month').textContent = `${viewYear}년 ${viewMonth + 1}월`;

    const datesElement = document.querySelector('.dates');
    datesElement.innerHTML = ''; // 이전 날짜 클리어

    dates.forEach((date, i) => {
        const dateElement = document.createElement('div');
        dateElement.classList.add('date');
        const formattedDate = formatDateComponent(date);
        dateElement.setAttribute('data-date', `${viewYear}-${viewMonth + 1}-${formattedDate}`);
        
        const spanElement = document.createElement('span');
        spanElement.classList.add(i >= firstDateIndex && i < lastDateIndex + 1 ? 'this' : 'other');
        spanElement.textContent = date;
        dateElement.appendChild(spanElement);

        // 날짜 클릭 이벤트 리스너 추가
        dateElement.addEventListener('click', function() {
            modal.style.display = 'block'; // 모달을 보이게 설정
        });

        // 최종적으로 dateElement를 datesElement에 추가
        datesElement.appendChild(dateElement);
    });
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();

    console.log(`현재 달력 월의 날짜는 ${viewMonth + 1}입니다.`);
    // 오늘 날짜 하이라이트
    if (viewMonth === todayMonth) {
        const datesElements = document.querySelectorAll('.this');
        for (let dateElement of datesElements) {
            const dateNum = parseInt(dateElement.innerText, 10);
            console.log(`현재 달력 월의 날짜는 ${dateNum}입니다.`); // 디버깅 정보

            if (dateNum === todayDate) {
                console.log(`오늘 날짜 ${todayDate}에 'today' 클래스를 추가합니다.`); // 디버깅 정보
                dateElement.classList.add('today');
                break;
            }
        }
    }
}

function updateCalendarWithData(data) {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const formattedData = data.map(item => ({
        ...item,
        date: `${viewYear}-${viewMonth + 1}-${formatDateComponent(item.date)}`
    }));

    const dates = document.querySelectorAll('.date');
    dates.forEach(dateElement => {
        const dataDate = dateElement.getAttribute('data-date');
        const dayData = formattedData.find(d => d.date === dataDate);
        if (dayData) {
            // 데이터에 따른 클래스 추가 등
        }
    });
}

var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];

span.onclick = function() {
    modal.style.display = 'none';
};

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};
