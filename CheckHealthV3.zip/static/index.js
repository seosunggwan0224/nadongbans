let date = new Date();

function formatDateComponent(component) {
    return component < 10 ? `0${component}` : component;
}

document.addEventListener('DOMContentLoaded', function() {
    startApp(); // 웹 페이지 로드 시 자동으로 달력을 렌더링하고 데이터를 가져옵니다.
});

function startApp() {
    renderCalendar(); // 달력 초기 상태를 렌더링합니다.
    fetchDataAndUpdate(); // 데이터 가져오기 및 업데이트
}

function fetchDataAndUpdate() {
    fetch('/process_voice_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: '음성 입력 시작' })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            updateCalendarWithData(data); // 서버 응답이 있을 경우 달력을 업데이트합니다.
        })
        .catch(error => console.error('Error:', error));
}

function renderCalendar() {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const prevLast = new Date(viewYear, viewMonth, 0);
    const thisLast = new Date(viewYear, viewMonth + 1, 0);

    const PLDate = prevLast.getDate();
    const PLDay = prevLast.getDay();

    const TLDate = thisLast.getDate();
    const TLDay = thisLast.getDay();

    const prevDates = [];
    const thisDates = [...Array(TLDate + 1).keys()].slice(1);
    const nextDates = [];

    if (PLDay !== 6) {
        for (let i = 0; i < PLDay + 1; i++) {
            prevDates.unshift(PLDate - i);
        }
    }

    for (let i = 1; i < 7 - TLDay; i++) {
        nextDates.push(i);
    }

    const dates = prevDates.concat(thisDates, nextDates);
    const firstDateIndex = dates.indexOf(1);
    const lastDateIndex = dates.lastIndexOf(TLDate);

    document.querySelector('.year-month').textContent = `${viewYear}년 ${viewMonth + 1}월`;

    const datesElement = document.querySelector('.dates');
    datesElement.innerHTML = ''; // 이전 날짜 클리어

    dates.forEach((date, i) => {
        const dateElement = document.createElement('div');
        dateElement.classList.add('date');
        const formattedDate = formatDateComponent(date);
        dateElement.setAttribute('data-date', `${viewYear}-${viewMonth}-${formattedDate}`);
        const spanElement = document.createElement('span');
        spanElement.classList.add(i >= firstDateIndex && i < lastDateIndex + 1 ? 'this' : 'other');
        spanElement.textContent = date;
        dateElement.appendChild(spanElement);

        datesElement.appendChild(dateElement);
    });

    // 오늘 날짜 하이라이트
    if (viewMonth === new Date().getMonth()) {
        for (let date of document.querySelectorAll('.this')) {
            if (+date.innerText === new Date().getDate()) {
                date.classList.add('today');
                break;
            }
        }
    }
}

function updateCalendarWithData(data) {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const formattedData = data.map(item => ({
        ...item,
        date: `${viewYear}-${viewMonth + 1}-${formatDateComponent(item.date)}`
    }));

    const dates = document.querySelectorAll('.date');
    dates.forEach(dateElement => {
        const dataDate = dateElement.getAttribute('data-date');
        const dayData = formattedData.find(d => d.date === dataDate);
        if (dayData) {
            // 데이터에 따른 클래스 추가 등
        }
    });
}

var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];

span.onclick = function() {
    modal.style.display = 'none';
};

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};
